import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const AdmZip = require('adm-zip');
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const HOST = '0.0.0.0';

app.use(cors());
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

const backupFile = path.join(__dirname, 'fleet_backup.json');
const altBackupFile = path.join(__dirname, 'fleet-database-backup.json');
const faniyatBackupFile = path.join(__dirname, 'faniyat_fuel_backup.json');

const isFaniyatType = (type) => type === 'faniyat' || type === 'fuel';

const safeReadJson = (filePath, fallback) => {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf-8');
    if (!raw.trim()) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
};

const safeWriteJson = (filePath, data) => {
  const tmpPath = `${filePath}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpPath, filePath);
  return fs.statSync(filePath).size;
};

const getTargetFile = (type) => {
  if (isFaniyatType(type)) return faniyatBackupFile;
  if (!fs.existsSync(backupFile) && fs.existsSync(altBackupFile)) return altBackupFile;
  return backupFile;
};

const handleBackupGet = (req, res) => {
  try {
    const type = String(req.query.type || 'fleet').toLowerCase();
    const fallback = isFaniyatType(type)
      ? { records: [], lastUpdated: null }
      : { trucks: [], drivers: [], zones: [], maintenances: [], fuelLogs: [] };

    res.json(safeReadJson(getTargetFile(type), fallback));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

const handleBackupPost = (req, res) => {
  try {
    const type = String(req.query.type || 'fleet').toLowerCase();
    const raw = req.body;
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      return res.status(400).json({ success: false, error: 'Invalid payload' });
    }

    let dataToSave = raw.appState && typeof raw.appState === 'object' ? raw.appState : raw;
    const updatedAt = new Date().toISOString();

    if (isFaniyatType(type)) {
      if (!Array.isArray(dataToSave.records)) {
        return res.status(400).json({ success: false, error: 'records must be an array' });
      }
      dataToSave = { ...dataToSave, lastUpdated: updatedAt };
    } else {
      dataToSave = { ...dataToSave, lastServerSync: updatedAt };
    }

    const bytes = safeWriteJson(getTargetFile(type), dataToSave);
    res.json({ success: true, updatedAt, bytes, type });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

app.get('/backup.php', handleBackupGet);
app.post('/backup.php', handleBackupPost);
app.get('/api/backup', handleBackupGet);
app.post('/api/backup', handleBackupPost);

app.get('/api/faniyat-fuel', (req, res) => {
  res.json(safeReadJson(faniyatBackupFile, { records: [], lastUpdated: null }));
});

app.post('/api/faniyat-fuel', (req, res) => {
  try {
    const raw = req.body;
    if (!raw || !Array.isArray(raw.records)) {
      return res.status(400).json({ success: false, error: 'records must be an array' });
    }

    const updatedAt = new Date().toISOString();
    const payload = { records: raw.records, lastUpdated: updatedAt };
    const bytes = safeWriteJson(faniyatBackupFile, payload);

    res.json({ success: true, updatedAt, bytes, count: raw.records.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/download', (req, res) => {
  try {
    const dateStr = new Date().toISOString().split('T')[0];
    const zip = new AdmZip();
    zip.addLocalFolder(__dirname, '', (filename) => {
      return !filename.includes('node_modules') && !filename.includes('.git') && !filename.includes('dist') && !filename.endsWith('.tmp');
    });
    const zipBuffer = zip.toBuffer();
    
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename=gestion_flotte_camions_${dateStr}.zip`);
    res.setHeader('Content-Length', zipBuffer.length);
    res.send(zipBuffer);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.use(express.static(__dirname));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.listen(PORT, HOST, () => {
  console.log(`Water Tanker Fleet Management Server running on http://${HOST}:${PORT}`);
});
