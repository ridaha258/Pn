<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, X-Fleet-Auth, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

function saveJsonData($filePath, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;

    // Try direct write first (most compatible with free PHP hostings like Byethost/InfinityFree)
    $res = @file_put_contents($filePath, $json, LOCK_EX);
    if ($res !== false) {
        @chmod($filePath, 0666);
        return true;
    }

    // Fallback: try temporary file
    $tmpPath = $filePath . '.tmp';
    if (@file_put_contents($tmpPath, $json) !== false) {
        if (@rename($tmpPath, $filePath)) {
            @chmod($filePath, 0666);
            return true;
        }
        @unlink($tmpPath);
    }

    return false;
}

$type = strtolower(trim((string)($_GET['type'] ?? 'fleet')));
$isFaniyat = $type === 'faniyat' || $type === 'fuel';
$backupFile = __DIR__ . ($isFaniyat ? '/faniyat_fuel_backup.json' : '/fleet_backup.json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (file_exists($backupFile)) {
        readfile($backupFile);
    } else {
        echo json_encode(
            $isFaniyat
                ? ['records' => [], 'lastUpdated' => null]
                : ['trucks' => [], 'drivers' => [], 'zones' => [], 'maintenances' => [], 'fuelLogs' => []],
            JSON_UNESCAPED_UNICODE
        );
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '', true);

    if (!is_array($decoded)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid JSON']);
        exit;
    }

    $data = isset($decoded['appState']) && is_array($decoded['appState'])
        ? $decoded['appState']
        : $decoded;
    $updatedAt = date('c');

    if ($isFaniyat) {
        if (!isset($data['records']) || !is_array($data['records'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'records must be an array']);
            exit;
        }
        $data['lastUpdated'] = $updatedAt;
    } else {
        $data['lastServerSync'] = $updatedAt;
    }

    if (!saveJsonData($backupFile, $data)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to write backup file']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'تم حفظ البيانات بنجاح',
        'updatedAt' => $updatedAt,
        'type' => $isFaniyat ? 'faniyat' : 'fleet'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Method not allowed']);

