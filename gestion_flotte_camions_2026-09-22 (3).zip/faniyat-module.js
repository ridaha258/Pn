// ==============================================================================
// قسم وقود الفنيات (Parc Technique Fuel Module) - قسم ثابت ومستقل بحسابه وبياناته
// ==============================================================================
(function () {
  const STORAGE_KEY = "fuel_faniyat_data_v1";
  let faniyatRecords = [];
  let isFaniyatActive = false;
  let activeFilterTruck = "ALL";
  let activeFilterStation = "ALL";
  let activeFilterMonth = "ALL";
  let activeFilterZone = "ALL";
  let activeSearchQuery = "";
  let editingRecordId = null;

  // 1. Initial Load from LocalStorage or Fetch from Server / Seed
  function initFaniyatData() {
    try {
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) {
        const parsed = JSON.parse(local);
        if (Array.isArray(parsed) && parsed.length > 0) {
          faniyatRecords = parsed;
          return;
        } else if (parsed && Array.isArray(parsed.records) && parsed.records.length > 0) {
          faniyatRecords = parsed.records;
          return;
        }
      }
    } catch (e) {
      console.warn("Faniyat local load error:", e);
    }

    // Fallback: Fetch from server API or seed JSON
    fetch("/api/faniyat-fuel")
      .then((res) => res.json())
      .then((data) => {
        if (data && Array.isArray(data.records) && data.records.length > 0) {
          faniyatRecords = data.records;
          saveFaniyatLocal();
          if (isFaniyatActive) renderFaniyatView();
        } else {
          fetch("/faniyat_fuel_backup.json")
            .then((r) => r.json())
            .then((seed) => {
              if (seed && Array.isArray(seed.records)) {
                faniyatRecords = seed.records;
                saveFaniyatLocal();
                if (isFaniyatActive) renderFaniyatView();
              }
            })
            .catch(() => {});
        }
      })
      .catch(() => {
        fetch("/faniyat_fuel_backup.json")
          .then((r) => r.json())
          .then((seed) => {
            if (seed && Array.isArray(seed.records)) {
              faniyatRecords = seed.records;
              saveFaniyatLocal();
              if (isFaniyatActive) renderFaniyatView();
            }
          })
          .catch(() => {});
      });
  }

  function saveFaniyatLocal() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(faniyatRecords));
      // Background server sync
      fetch("/api/faniyat-fuel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records: faniyatRecords }),
      }).catch(() => {});
    } catch (e) {
      console.error("Faniyat save error:", e);
    }
  }

  // 2. Formatters
  function formatMAD(val) {
    const num = Number(val) || 0;
    return (
      num.toLocaleString("fr-FR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }) + " د.م"
    );
  }

  // 3. Mount Tab in Main Navigation (With Fixed Sections)
  function mountNavigationTab() {
    if (document.getElementById("nav-tab-faniyat")) return;

    // Look for top navigation bar containing tabs
    const navContainers = document.querySelectorAll("header nav, nav, [role='tablist'], .flex.flex-wrap.gap-2, .flex.gap-2, .flex.items-center.gap-1, .flex.items-center.gap-2");
    let targetNav = null;

    for (let nav of navContainers) {
      const text = nav.textContent || "";
      if (
        (text.includes("لوحة التحكم") || text.includes("الأسطول") || text.includes("الصيانة") || text.includes("المحروقات") || text.includes("الفيدانج")) &&
        nav.children.length >= 3
      ) {
        targetNav = nav;
        break;
      }
    }

    if (!targetNav) return;

    const isFr = document.documentElement.lang === "fr";
    const tabBtn = document.createElement("button");
    tabBtn.id = "nav-tab-faniyat";
    tabBtn.type = "button";
    tabBtn.className =
      "nav-tab-faniyat-btn inline-flex items-center gap-2 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all border cursor-pointer select-none";
    
    // Copy computed styles or class patterns of other nav buttons
    const siblingBtn = targetNav.querySelector("button, a");
    if (siblingBtn && siblingBtn.className) {
      tabBtn.className = siblingBtn.className + " nav-tab-faniyat-btn";
    }

    tabBtn.innerHTML = `
      <span style="font-size: 15px; display: inline-block;">⛽</span>
      <span class="font-extrabold">${isFr ? "Carburant Faniyat" : "وقود فنيات"}</span>
      <span id="faniyat-nav-count-badge" style="background: rgba(245, 158, 11, 0.25); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4); padding: 1px 6px; border-radius: 9999px; font-size: 11px; font-weight: 800;">30</span>
    `;

    tabBtn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      activateFaniyatSection();
    };

    // Insert next to "المحروقات" or "الفيدانج" if exists, otherwise append
    let inserted = false;
    for (let child of targetNav.children) {
      const cText = child.textContent || "";
      if (cText.includes("المحروقات") || cText.includes("الفيدانج") || cText.includes("Carburant") || cText.includes("Vidange")) {
        child.insertAdjacentElement("afterend", tabBtn);
        inserted = true;
        break;
      }
    }
    if (!inserted) {
      targetNav.appendChild(tabBtn);
    }

    updateTabVisuals();

    // Attach click interceptor for all other nav buttons to exit faniyat view
    document.addEventListener("click", function (ev) {
      const el = ev.target.closest("button, a");
      if (!el || el.id === "nav-tab-faniyat" || el.closest("#faniyat-main-container") || el.closest("#faniyat-modal")) return;

      const text = el.textContent || "";
      if (
        text.includes("لوحة التحكم") ||
        text.includes("الأسطول") ||
        text.includes("الصيانة") ||
        text.includes("الفيدانج") ||
        text.includes("المحروقات") ||
        text.includes("الحصص") ||
        text.includes("التقارير") ||
        text.includes("النسخ الاحتياطي") ||
        text.includes("Tableau de bord") ||
        text.includes("Flotte") ||
        text.includes("Maintenance") ||
        text.includes("Vidange") ||
        text.includes("Dotations") ||
        text.includes("Rapports")
      ) {
        deactivateFaniyatSection();
      }
    }, true);
  }

  function activateFaniyatSection() {
    isFaniyatActive = true;
    updateTabVisuals();
    hideOtherSections();
    renderFaniyatView();
    // Scroll smoothly to top
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function deactivateFaniyatSection() {
    isFaniyatActive = false;
    updateTabVisuals();
    const fContainer = document.getElementById("faniyat-main-container");
    if (fContainer) fContainer.style.display = "none";
    showOtherSections();
  }

  function updateTabVisuals() {
    const tab = document.getElementById("nav-tab-faniyat");
    if (!tab) return;
    const isLight = document.documentElement.classList.contains("light");

    if (isFaniyatActive) {
      tab.style.background = isLight ? "#f59e0b" : "#f59e0b";
      tab.style.borderColor = "#d97706";
      tab.style.color = "#000";
      tab.style.fontWeight = "900";
      tab.style.boxShadow = "0 4px 14px rgba(245, 158, 11, 0.4)";
      const badge = tab.querySelector("#faniyat-nav-count-badge");
      if (badge) {
        badge.style.background = "#000";
        badge.style.color = "#f59e0b";
        badge.style.borderColor = "#000";
      }
    } else {
      tab.style.background = isLight ? "#f1f5f9" : "rgba(30, 41, 59, 0.7)";
      tab.style.borderColor = isLight ? "#cbd5e1" : "rgba(71, 85, 105, 0.5)";
      tab.style.color = isLight ? "#1e293b" : "#cbd5e1";
      tab.style.fontWeight = "700";
      tab.style.boxShadow = "none";
      const badge = tab.querySelector("#faniyat-nav-count-badge");
      if (badge) {
        badge.style.background = "rgba(245, 158, 11, 0.2)";
        badge.style.color = "#f59e0b";
        badge.style.borderColor = "rgba(245, 158, 11, 0.35)";
      }
    }
  }

  function hideOtherSections() {
    const root = document.getElementById("root");
    if (!root) return;
    const directChildren = root.children;
    for (let i = 0; i < directChildren.length; i++) {
      const child = directChildren[i];
      if (child.id !== "faniyat-main-container") {
        const mainEl = child.querySelector("main") || child.querySelector(".container") || child;
        if (mainEl && mainEl.id !== "faniyat-main-container") {
          mainEl.setAttribute("data-faniyat-prev-display", mainEl.style.display || "");
          mainEl.style.display = "none";
        }
      }
    }
  }

  function showOtherSections() {
    const hiddenEls = document.querySelectorAll("[data-faniyat-prev-display]");
    hiddenEls.forEach((el) => {
      el.style.display = el.getAttribute("data-faniyat-prev-display");
      el.removeAttribute("data-faniyat-prev-display");
    });
  }

  // 4. Render Independent View
  function renderFaniyatView() {
    let container = document.getElementById("faniyat-main-container");
    const root = document.getElementById("root");
    if (!root) return;

    if (!container) {
      container = document.createElement("div");
      container.id = "faniyat-main-container";
      container.className = "w-full max-w-7xl mx-auto px-4 py-6 font-['Cairo',sans-serif]";
      root.appendChild(container);
    }

    container.style.display = "block";
    const isFr = document.documentElement.lang === "fr";

    // Filter calculations
    const filtered = faniyatRecords.filter((r) => {
      if (activeFilterTruck !== "ALL" && r.truckPlate !== activeFilterTruck) return false;
      if (activeFilterStation !== "ALL" && r.station !== activeFilterStation) return false;
      if (activeFilterZone !== "ALL" && r.zone !== activeFilterZone) return false;
      if (activeFilterMonth !== "ALL") {
        if (!r.date || !r.date.startsWith(activeFilterMonth)) return false;
      }
      if (activeSearchQuery) {
        const q = activeSearchQuery.toLowerCase();
        const match =
          (r.truckPlate && r.truckPlate.toLowerCase().includes(q)) ||
          (r.truckType && r.truckType.toLowerCase().includes(q)) ||
          (r.zone && r.zone.toLowerCase().includes(q)) ||
          (r.driver && r.driver.toLowerCase().includes(q)) ||
          (r.station && r.station.toLowerCase().includes(q)) ||
          (r.observation && r.observation.toLowerCase().includes(q));
        if (!match) return false;
      }
      return true;
    });

    // Aggregates
    const totalMAD = filtered.reduce((acc, r) => acc + (Number(r.total) || 0), 0);
    const totalGasoil = filtered.reduce((acc, r) => acc + (Number(r.gasoil) || 0), 0);
    const totalEssence = filtered.reduce((acc, r) => acc + (Number(r.essence) || 0), 0);
    const avgCons =
      filtered.length > 0
        ? (filtered.reduce((acc, r) => acc + (Number(r.consumption) || 0), 0) / filtered.length).toFixed(1)
        : "0.0";
    const uniqueTrucksCount = new Set(filtered.map((r) => r.truckPlate)).size;

    // Distinct lists for dropdowns
    const allTrucks = Array.from(new Set(faniyatRecords.map((r) => r.truckPlate).filter(Boolean))).sort();
    const allStations = Array.from(new Set(faniyatRecords.map((r) => r.station).filter(Boolean))).sort();
    const allZones = Array.from(new Set(faniyatRecords.map((r) => r.zone).filter(Boolean))).sort();

    container.innerHTML = `
      <!-- Top Fixed Banner -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-amber-500/15 via-[#182330] to-[#121820] border border-amber-500/35 rounded-2xl p-5 mb-6 shadow-xl">
        <div class="flex items-center gap-3.5">
          <div class="w-13 h-13 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-3xl shadow-inner">
            ⛽
          </div>
          <div>
            <div class="flex items-center gap-2.5 flex-wrap">
              <h1 class="text-xl sm:text-2xl font-black text-amber-400">
                ${isFr ? "Section Carburant Parc Technique" : "قسم وقود الفنيات (Parc Technique)"}
              </h1>
              <span class="bg-amber-500 text-slate-950 text-xs font-black px-3 py-0.5 rounded-full shadow-sm">
                ${isFr ? "Section Autonome" : "قسم ثابت ومستقل بحسابه"}
              </span>
              <span class="bg-slate-800 text-slate-300 border border-slate-700 text-xs font-bold px-2.5 py-0.5 rounded-full">
                30 ${isFr ? "Camions" : "شاحنة فنية"}
              </span>
            </div>
            <p class="text-xs sm:text-sm text-slate-300 font-semibold mt-1">
              ${isFr ? "Comptabilité, consommation et suivi indépendant de toutes les dotations des faniyat" : "تسيير وحساب وتدقيق استهلاك وقود شاحنات الفنيات الـ 30 بحساب وميزانية مستقلة تماماً"}
            </p>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <button type="button" onclick="window.openFaniyatModal()" class="flex-1 md:flex-none inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs sm:text-sm cursor-pointer">
            <span style="font-size: 15px;">➕</span>
            <span>${isFr ? "Nouvelle dotation" : "إضافة تعبئة وقود"}</span>
          </button>
          <button type="button" onclick="window.exportFaniyatCSV()" class="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer" title="${isFr ? "Exporter en Excel / CSV" : "تصدير إلى ملف إكسيل CSV"}">
            <span>📥</span>
            <span>${isFr ? "Excel" : "تصدير Excel"}</span>
          </button>
          <button type="button" onclick="window.printFaniyatReport()" class="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer" title="${isFr ? "Imprimer le rapport" : "طباعة تقرير وقود الفنيات"}">
            <span>🖨️</span>
            <span>${isFr ? "Imprimer" : "طباعة التقرير"}</span>
          </button>
        </div>
      </div>

      <!-- Quick Truck Pills Strip -->
      <div class="bg-[#141d26] border border-slate-800 rounded-2xl p-3 mb-6 shadow-md overflow-hidden">
        <div class="flex items-center gap-2 mb-2 text-xs font-extrabold text-slate-300">
          <span>🚚</span>
          <span>${isFr ? "Accès rapide par camion technique :" : "الوصول السريع حسب الشاحنة الفنية :"}</span>
        </div>
        <div class="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button type="button" onclick="window.setFaniyatTruckFilter('ALL')" class="px-3 py-1.5 rounded-xl font-extrabold transition-all whitespace-nowrap cursor-pointer border ${activeFilterTruck === "ALL" ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md" : "bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700"}">
            ${isFr ? "Tous (30)" : "الكل (30)"}
          </button>
          ${allTrucks
            .map(
              (t) => `
            <button type="button" onclick="window.setFaniyatTruckFilter('${t}')" class="px-2.5 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer border ${activeFilterTruck === t ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md font-extrabold" : "bg-slate-800/70 text-slate-300 border-slate-700/80 hover:bg-slate-700"}">
              ${t}
            </button>
          `
            )
            .join("")}
        </div>
      </div>

      <!-- KPI Summary Cards -->
      <div class="grid grid-cols-2 lg:grid-cols-6 gap-3 sm:gap-4 mb-6">
        <!-- Total Cost -->
        <div class="col-span-2 bg-[#141d26] border border-amber-500/40 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-400">${isFr ? "Total Carburant Faniyat" : "إجمالي مصاريف وقود الفنيات"}</span>
            <span class="text-amber-400 font-extrabold text-sm">MAD</span>
          </div>
          <div class="mt-2 text-xl sm:text-2xl font-black text-amber-300">
            ${formatMAD(totalMAD)}
          </div>
          <div class="mt-2 text-[11px] text-slate-400 font-semibold flex items-center justify-between border-t border-slate-800 pt-1.5">
            <span>${isFr ? "Total opérations :" : "عدد العمليات :"} <strong class="text-slate-200">${filtered.length}</strong></span>
            <span>${isFr ? "Camions actifs :" : "الشاحنات :"} <strong class="text-slate-200">${uniqueTrucksCount}</strong></span>
          </div>
        </div>

        <!-- Gasoil -->
        <div class="bg-[#141d26] border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col justify-between">
          <span class="text-xs font-bold text-slate-400">${isFr ? "Total Gasoil" : "إجمالي الغازوال"}</span>
          <div class="mt-1.5 text-lg sm:text-xl font-extrabold text-sky-400">
            ${formatMAD(totalGasoil)}
          </div>
          <span class="text-[10px] text-slate-500 font-bold mt-1">${((totalGasoil / (totalMAD || 1)) * 100).toFixed(0)}% ${isFr ? "du budget" : "من الحصة"}</span>
        </div>

        <!-- Essence -->
        <div class="bg-[#141d26] border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col justify-between">
          <span class="text-xs font-bold text-slate-400">${isFr ? "Total Essence" : "إجمالي البنزين"}</span>
          <div class="mt-1.5 text-lg sm:text-xl font-extrabold text-emerald-400">
            ${formatMAD(totalEssence)}
          </div>
          <span class="text-[10px] text-slate-500 font-bold mt-1">${((totalEssence / (totalMAD || 1)) * 100).toFixed(0)}% ${isFr ? "du budget" : "من الحصة"}</span>
        </div>

        <!-- Consommation Moyenne -->
        <div class="bg-[#141d26] border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col justify-between">
          <span class="text-xs font-bold text-slate-400">${isFr ? "Moy. Conso." : "متوسط الاستهلاك"}</span>
          <div class="mt-1.5 text-lg sm:text-xl font-extrabold text-purple-400">
            ${avgCons} %
          </div>
          <span class="text-[10px] text-slate-500 font-bold mt-1">${isFr ? "Pourcentage" : "معدل استهلاك الأسطول"}</span>
        </div>

        <!-- Total Parc -->
        <div class="bg-[#141d26] border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col justify-between">
          <span class="text-xs font-bold text-slate-400">${isFr ? "Parc Faniyat" : "الأسطول الفني"}</span>
          <div class="mt-1.5 text-lg sm:text-xl font-extrabold text-amber-400">
            30 <span class="text-xs text-slate-400 font-medium">${isFr ? "Camions" : "شاحنة"}</span>
          </div>
          <span class="text-[10px] text-slate-500 font-bold mt-1">${isFr ? "Feuilles 1 à 30" : "الشاحنات الفنية المسجلة"}</span>
        </div>
      </div>

      <!-- Filter Controls Bar -->
      <div class="bg-[#141d26] border border-slate-800 rounded-2xl p-4 mb-6 shadow-md">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <!-- Search -->
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">${isFr ? "Recherche rapide" : "البحث السريع"}</label>
            <input type="text" id="faniyat-search-input" value="${activeSearchQuery}" placeholder="${isFr ? "Matricule, chauffeur, zone..." : "رقم الشاحنة، السائق، المحطة..."}" class="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-3 py-2 text-xs sm:text-sm focus:outline-none focus:border-amber-500">
          </div>

          <!-- Truck Select -->
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">${isFr ? "Camion Technique" : "الشاحنة الفنية"}</label>
            <select id="faniyat-truck-select" class="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-3 py-2 text-xs sm:text-sm focus:outline-none focus:border-amber-500">
              <option value="ALL">${isFr ? "Tous les camions (30)" : "كل الشاحنات الفنية (30)"}</option>
              ${allTrucks.map((t) => `<option value="${t}" ${activeFilterTruck === t ? "selected" : ""}>${t}</option>`).join("")}
            </select>
          </div>

          <!-- Station Select -->
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">${isFr ? "Station" : "محطة الوقود"}</label>
            <select id="faniyat-station-select" class="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-3 py-2 text-xs sm:text-sm focus:outline-none focus:border-amber-500">
              <option value="ALL">${isFr ? "Toutes les stations" : "كل المحطات"}</option>
              ${allStations.map((s) => `<option value="${s}" ${activeFilterStation === s ? "selected" : ""}>${s}</option>`).join("")}
            </select>
          </div>

          <!-- Zone Select -->
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">${isFr ? "Commune / Zone" : "الجماعة / الدائرة"}</label>
            <select id="faniyat-zone-select" class="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-3 py-2 text-xs sm:text-sm focus:outline-none focus:border-amber-500">
              <option value="ALL">${isFr ? "Toutes les zones" : "كل الجماعات والدوائر"}</option>
              ${allZones.map((z) => `<option value="${z}" ${activeFilterZone === z ? "selected" : ""}>${z}</option>`).join("")}
            </select>
          </div>

          <!-- Month Filter -->
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">${isFr ? "Période / Mois" : "الشهر / الفترة"}</label>
            <select id="faniyat-month-select" class="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-3 py-2 text-xs sm:text-sm focus:outline-none focus:border-amber-500">
              <option value="ALL" ${activeFilterMonth === "ALL" ? "selected" : ""}>${isFr ? "Toute l'année 2026" : "كل شهور سنة 2026"}</option>
              <option value="2026-01" ${activeFilterMonth === "2026-01" ? "selected" : ""}>يناير 2026 (Janvier)</option>
              <option value="2026-02" ${activeFilterMonth === "2026-02" ? "selected" : ""}>فبراير 2026 (Février)</option>
              <option value="2026-03" ${activeFilterMonth === "2026-03" ? "selected" : ""}>مارس 2026 (Mars)</option>
              <option value="2026-04" ${activeFilterMonth === "2026-04" ? "selected" : ""}>أبريل 2026 (Avril)</option>
              <option value="2026-05" ${activeFilterMonth === "2026-05" ? "selected" : ""}>ماي 2026 (Mai)</option>
              <option value="2026-06" ${activeFilterMonth === "2026-06" ? "selected" : ""}>يونيو 2026 (Juin)</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Data Table Card -->
      <div class="bg-[#141d26] border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div class="p-4 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2">
          <div class="flex items-center gap-2">
            <span class="font-extrabold text-sm sm:text-base text-slate-200">${isFr ? "Enregistrements de carburant" : "سجل تعبئات وقود الفنيات"}</span>
            <span class="bg-slate-800 text-amber-400 text-xs px-2.5 py-0.5 rounded-full font-bold border border-slate-700">
              ${filtered.length} ${isFr ? "lignes" : "تعبئة"}
            </span>
          </div>
          <div class="text-xs text-slate-400 font-bold">
            ${isFr ? "Total affiché :" : "المجموع الظاهر :"} <span class="text-amber-400 font-extrabold text-sm">${formatMAD(totalMAD)}</span>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-right text-xs sm:text-sm" style="direction: ${isFr ? "ltr" : "rtl"};">
            <thead class="bg-slate-900/90 text-slate-300 border-b border-slate-800 text-[11px] sm:text-xs uppercase font-bold">
              <tr>
                <th class="px-3.5 py-3">${isFr ? "Date" : "التاريخ"}</th>
                <th class="px-3.5 py-3">${isFr ? "Matricule & Type" : "الشاحنة / النوع"}</th>
                <th class="px-3.5 py-3">${isFr ? "Commune / Cercle" : "الجماعة / الدائرة"}</th>
                <th class="px-3.5 py-3">${isFr ? "Station" : "المحطة"}</th>
                <th class="px-3.5 py-3 text-sky-400">${isFr ? "Gasoil (MAD)" : "الغازوال (د.م)"}</th>
                <th class="px-3.5 py-3 text-emerald-400">${isFr ? "Essence (MAD)" : "البنزين (د.م)"}</th>
                <th class="px-3.5 py-3">${isFr ? "P.U (Gasoil)" : "سعر اللتر"}</th>
                <th class="px-3.5 py-3">${isFr ? "Chauffeur" : "السائق"}</th>
                <th class="px-3.5 py-3">${isFr ? "Conso %" : "الاستهلاك %"}</th>
                <th class="px-3.5 py-3">${isFr ? "Compteur (Km)" : "العداد"}</th>
                <th class="px-3.5 py-3 text-amber-400 font-black">${isFr ? "Total (MAD)" : "المجموع الإجمالي"}</th>
                <th class="px-3.5 py-3">${isFr ? "Observation" : "ملاحظة"}</th>
                <th class="px-3.5 py-3 text-center">${isFr ? "Actions" : "إجراءات"}</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-medium">
              ${
                filtered.length === 0
                  ? `<tr><td colspan="13" class="text-center py-12 text-slate-400 text-sm font-bold">${isFr ? "Aucun enregistrement trouvé." : "لا توجد سجلات تطابق معايير البحث."}</td></tr>`
                  : filtered
                      .map((r) => {
                        return `
                  <tr class="hover:bg-slate-800/40 transition-colors">
                    <td class="px-3.5 py-3 whitespace-nowrap text-slate-300 font-bold">${r.date || "—"}</td>
                    <td class="px-3.5 py-3 whitespace-nowrap">
                      <div class="font-extrabold text-amber-400">${r.truckPlate}</div>
                      <div class="text-[11px] text-slate-400">${r.truckType || ""}</div>
                    </td>
                    <td class="px-3.5 py-3 text-slate-300 text-xs">${r.zone || "—"}</td>
                    <td class="px-3.5 py-3 whitespace-nowrap">
                      <span class="bg-slate-800 text-slate-200 border border-slate-700 px-2 py-0.5 rounded-lg text-[11px] font-bold">
                        ${r.station || "SHELL"}
                      </span>
                    </td>
                    <td class="px-3.5 py-3 text-sky-400 font-bold whitespace-nowrap">${r.gasoil ? Number(r.gasoil).toLocaleString("fr-FR") : "0"}</td>
                    <td class="px-3.5 py-3 text-emerald-400 font-bold whitespace-nowrap">${r.essence ? Number(r.essence).toLocaleString("fr-FR") : "0"}</td>
                    <td class="px-3.5 py-3 text-slate-300 whitespace-nowrap text-xs">${r.puGasoil ? r.puGasoil + " د.م" : "—"}</td>
                    <td class="px-3.5 py-3 text-slate-200 whitespace-nowrap font-semibold">${r.driver || "—"}</td>
                    <td class="px-3.5 py-3 whitespace-nowrap">
                      <span class="text-purple-300 font-bold">${r.consumption ? r.consumption + "%" : "—"}</span>
                    </td>
                    <td class="px-3.5 py-3 text-slate-300 whitespace-nowrap text-xs">${r.mileage ? Number(r.mileage).toLocaleString("fr-FR") + " km" : "—"}</td>
                    <td class="px-3.5 py-3 text-amber-300 font-black whitespace-nowrap">${Number(r.total || 0).toLocaleString("fr-FR")} د.م</td>
                    <td class="px-3.5 py-3 text-slate-400 text-xs">${r.observation || "—"}</td>
                    <td class="px-3.5 py-3 text-center whitespace-nowrap">
                      <div class="inline-flex items-center gap-1.5">
                        <button type="button" onclick="window.editFaniyatRecord('${r.id}')" class="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 transition-all text-xs cursor-pointer" title="${isFr ? "Modifier" : "تعديل"}">✏️</button>
                        <button type="button" onclick="window.deleteFaniyatRecord('${r.id}')" class="p-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-all text-xs cursor-pointer" title="${isFr ? "Supprimer" : "حذف"}">🗑️</button>
                      </div>
                    </td>
                  </tr>
                `;
                      })
                      .join("")
              }
            </tbody>
          </table>
        </div>
      </div>
    `;

    // Quick filter helpers
    window.setFaniyatTruckFilter = function (plate) {
      activeFilterTruck = plate;
      renderFaniyatView();
    };

    // Reattach Filter Event Handlers
    const searchInput = document.getElementById("faniyat-search-input");
    if (searchInput) {
      searchInput.oninput = function (e) {
        activeSearchQuery = e.target.value;
        renderFaniyatView();
        const freshInput = document.getElementById("faniyat-search-input");
        if (freshInput) {
          freshInput.focus();
          freshInput.selectionStart = freshInput.selectionEnd = freshInput.value.length;
        }
      };
    }

    const truckSelect = document.getElementById("faniyat-truck-select");
    if (truckSelect) {
      truckSelect.onchange = function (e) {
        activeFilterTruck = e.target.value;
        renderFaniyatView();
      };
    }

    const stationSelect = document.getElementById("faniyat-station-select");
    if (stationSelect) {
      stationSelect.onchange = function (e) {
        activeFilterStation = e.target.value;
        renderFaniyatView();
      };
    }

    const zoneSelect = document.getElementById("faniyat-zone-select");
    if (zoneSelect) {
      zoneSelect.onchange = function (e) {
        activeFilterZone = e.target.value;
        renderFaniyatView();
      };
    }

    const monthSelect = document.getElementById("faniyat-month-select");
    if (monthSelect) {
      monthSelect.onchange = function (e) {
        activeFilterMonth = e.target.value;
        renderFaniyatView();
      };
    }
  }

  // 5. Modals for Add / Edit
  window.openFaniyatModal = function (recordId) {
    editingRecordId = recordId || null;
    let rec = {
      id: "fn-" + Date.now(),
      truckPlate: "240068 M",
      truckType: "DONG FENG 4 T",
      zone: "CT OULED YAICH CERCLE BENI MELLAL",
      date: new Date().toISOString().split("T")[0],
      gasoil: 2000,
      essence: 0,
      station: "SHELL",
      puGasoil: 12.89,
      puEssence: 0,
      driver: "",
      consumption: 28,
      mileage: 0,
      total: 2000,
      observation: "",
    };

    if (recordId) {
      const found = faniyatRecords.find((r) => r.id === recordId);
      if (found) rec = { ...found };
    }

    const isFr = document.documentElement.lang === "fr";
    let modal = document.getElementById("faniyat-modal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "faniyat-modal";
      document.body.appendChild(modal);
    }

    modal.innerHTML = `
      <div style="position: fixed; inset: 0; z-index: 100000; background: rgba(0,0,0,0.8); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; padding: 16px; font-family: 'Cairo', sans-serif;">
        <div style="background: #141d26; border: 1.5px solid #f59e0b; border-radius: 20px; width: 100%; max-width: 620px; max-height: 90vh; overflow-y: auto; padding: 24px; color: #f8fafc; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.9); direction: ${isFr ? "ltr" : "rtl"};">
          <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #334155; padding-bottom: 14px; margin-bottom: 18px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="font-size: 24px;">⛽</span>
              <h3 style="font-size: 18px; font-weight: 800; color: #f59e0b; margin: 0;">
                ${editingRecordId ? (isFr ? "Modifier la dotation" : "تعديل تعبئة وقود فنية") : (isFr ? "Nouvelle dotation carburant" : "إضافة تعبئة وقود فنية جديدة")}
              </h3>
            </div>
            <button type="button" onclick="document.getElementById('faniyat-modal').remove()" style="background: transparent; border: none; color: #94a3b8; font-size: 20px; cursor: pointer;">✕</button>
          </div>

          <form id="faniyat-form" onsubmit="window.saveFaniyatForm(event)">
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px;">
              <!-- Matricule -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Matricule de la camion" : "رقم لوحة الشاحنة الفنية"}</label>
                <input type="text" id="fn-field-plate" required value="${rec.truckPlate || ""}" placeholder="مثال: 240068 M" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Type -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Type / Capacité" : "نوع الشاحنة / الحمولة"}</label>
                <input type="text" id="fn-field-type" value="${rec.truckType || ""}" placeholder="مثال: DONG FENG 4 T" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Zone / Cercle -->
              <div style="grid-column: span 2;">
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Commune / Cercle" : "الجماعة / الدائرة"}</label>
                <input type="text" id="fn-field-zone" value="${rec.zone || ""}" placeholder="مثال: CT OULED YAICH CERCLE BENI MELLAL" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Date -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Date de plein" : "تاريخ التعبئة"}</label>
                <input type="date" id="fn-field-date" required value="${rec.date || ""}" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Station -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Station de service" : "محطة الوقود"}</label>
                <input type="text" id="fn-field-station" required value="${rec.station || "SHELL"}" placeholder="SHELL / PETRO BIG / ZIZ..." style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Gasoil Amount -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #38bdf8; margin-bottom: 4px;">${isFr ? "Montant Gasoil (MAD)" : "مبلغ الغازوال (د.م)"}</label>
                <input type="number" step="any" id="fn-field-gasoil" value="${rec.gasoil || 0}" oninput="window.calcFaniyatTotal()" style="width: 100%; background: #0f172a; border: 1px solid #0284c7; color: #38bdf8; font-weight: bold; padding: 8px 12px; border-radius: 10px; font-size: 14px;">
              </div>

              <!-- Essence Amount -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #34d399; margin-bottom: 4px;">${isFr ? "Montant Essence (MAD)" : "مبلغ البنزين (د.م)"}</label>
                <input type="number" step="any" id="fn-field-essence" value="${rec.essence || 0}" oninput="window.calcFaniyatTotal()" style="width: 100%; background: #0f172a; border: 1px solid #059669; color: #34d399; font-weight: bold; padding: 8px 12px; border-radius: 10px; font-size: 14px;">
              </div>

              <!-- PU Gasoil -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Prix unitaire Gasoil (MAD)" : "سعر لتر الغازوال (د.م)"}</label>
                <input type="number" step="0.01" id="fn-field-pugasoil" value="${rec.puGasoil || 0}" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Chauffeur -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Nom du chauffeur" : "اسم السائق"}</label>
                <input type="text" id="fn-field-driver" value="${rec.driver || ""}" placeholder="مثال: abdelkarim" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Compteur KM -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Index Compteur (Km)" : "عداد الكيلومتر (Km)"}</label>
                <input type="number" id="fn-field-mileage" value="${rec.mileage || 0}" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Conso % -->
              <div>
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Taux de consommation %" : "نسبة الاستهلاك %"}</label>
                <input type="number" step="0.01" id="fn-field-consumption" value="${rec.consumption || 0}" style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>

              <!-- Total Calculated -->
              <div style="grid-column: span 2; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.35); padding: 12px; border-radius: 12px; display: flex; align-items: center; justify-content: space-between;">
                <span style="font-weight: 700; color: #f59e0b; font-size: 14px;">${isFr ? "Total à payer (Gasoil + Essence) :" : "المجموع الإجمالي للتعبئة (غازوال + بنزين) :"}</span>
                <span id="fn-modal-total-display" style="font-size: 20px; font-weight: 900; color: #fef08a;">${(Number(rec.total) || 0).toLocaleString("fr-FR")} د.م</span>
              </div>

              <!-- Observation -->
              <div style="grid-column: span 2;">
                <label style="display: block; font-size: 12px; font-weight: 700; color: #94a3b8; margin-bottom: 4px;">${isFr ? "Observations / Suppléments" : "الملاحظات والإضافات (AdBlue، تشحيم، غسيل...)"}</label>
                <input type="text" id="fn-field-observation" value="${rec.observation || ""}" placeholder="مثال: adblue, lavage, huile moteur..." style="width: 100%; background: #0f172a; border: 1px solid #475569; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 13px;">
              </div>
            </div>

            <div style="display: flex; align-items: center; justify-content: flex-end; gap: 10px; margin-top: 22px; border-top: 1px solid #334155; padding-top: 16px;">
              <button type="button" onclick="document.getElementById('faniyat-modal').remove()" style="background: #334155; color: #e2e8f0; font-weight: 700; padding: 9px 18px; border-radius: 10px; border: none; cursor: pointer; font-size: 13px;">
                ${isFr ? "Annuler" : "إلغاء"}
              </button>
              <button type="submit" style="background: #f59e0b; color: #000; font-weight: 800; padding: 9px 24px; border-radius: 10px; border: none; cursor: pointer; font-size: 13px; box-shadow: 0 4px 14px rgba(245,158,11,0.35);">
                ${isFr ? "Enregistrer" : "حفظ التعبئة"}
              </button>
            </div>
          </form>
        </div>
      </div>
    `;
  };

  window.calcFaniyatTotal = function () {
    const gasoil = parseFloat(document.getElementById("fn-field-gasoil")?.value) || 0;
    const essence = parseFloat(document.getElementById("fn-field-essence")?.value) || 0;
    const total = gasoil + essence;
    const disp = document.getElementById("fn-modal-total-display");
    if (disp) {
      disp.textContent = total.toLocaleString("fr-FR") + " د.م";
    }
  };

  window.saveFaniyatForm = function (e) {
    e.preventDefault();
    const gasoil = parseFloat(document.getElementById("fn-field-gasoil")?.value) || 0;
    const essence = parseFloat(document.getElementById("fn-field-essence")?.value) || 0;

    const recordData = {
      id: editingRecordId || "fn-" + Date.now(),
      truckPlate: (document.getElementById("fn-field-plate")?.value || "").trim().toUpperCase(),
      truckType: (document.getElementById("fn-field-type")?.value || "").trim(),
      zone: (document.getElementById("fn-field-zone")?.value || "").trim(),
      date: document.getElementById("fn-field-date")?.value || "",
      station: (document.getElementById("fn-field-station")?.value || "SHELL").trim(),
      gasoil: gasoil,
      essence: essence,
      puGasoil: parseFloat(document.getElementById("fn-field-pugasoil")?.value) || 0,
      driver: (document.getElementById("fn-field-driver")?.value || "").trim(),
      mileage: parseInt(document.getElementById("fn-field-mileage")?.value, 10) || 0,
      consumption: parseFloat(document.getElementById("fn-field-consumption")?.value) || 0,
      total: gasoil + essence,
      observation: (document.getElementById("fn-field-observation")?.value || "").trim(),
    };

    if (editingRecordId) {
      const idx = faniyatRecords.findIndex((r) => r.id === editingRecordId);
      if (idx !== -1) faniyatRecords[idx] = recordData;
    } else {
      faniyatRecords.unshift(recordData);
    }

    saveFaniyatLocal();
    const modal = document.getElementById("faniyat-modal");
    if (modal) modal.remove();
    renderFaniyatView();
  };

  window.editFaniyatRecord = function (id) {
    window.openFaniyatModal(id);
  };

  window.deleteFaniyatRecord = function (id) {
    const isFr = document.documentElement.lang === "fr";
    if (!confirm(isFr ? "Supprimer cet enregistrement ?" : "هل أنت متأكد من حذف هذا السجل؟")) return;

    const prevBackup = JSON.stringify(faniyatRecords);
    localStorage.setItem("faniyat_last_deleted", prevBackup);
    faniyatRecords = faniyatRecords.filter((r) => r.id !== id);
    saveFaniyatLocal();
    renderFaniyatView();
  };

  // 6. Export & Print
  window.exportFaniyatCSV = function () {
    let csv = "\uFEFFDate,Matricule,Type,Zone,Station,Gasoil (MAD),Essence (MAD),PU Gasoil,Chauffeur,Consommation %,Kilometrage,Total (MAD),Observation\n";
    faniyatRecords.forEach((r) => {
      csv += `"${r.date || ""}","${r.truckPlate || ""}","${r.truckType || ""}","${r.zone || ""}","${r.station || ""}","${r.gasoil || 0}","${r.essence || 0}","${r.puGasoil || 0}","${r.driver || ""}","${r.consumption || 0}","${r.mileage || 0}","${r.total || 0}","${r.observation || ""}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `carburant_faniyat_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  window.printFaniyatReport = function () {
    window.print();
  };

  // Initialize
  initFaniyatData();

  // Watch DOM and ensure tab is always present and positioned with permanent tabs
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountNavigationTab);
  } else {
    setTimeout(mountNavigationTab, 300);
  }
  setInterval(mountNavigationTab, 1500);
})();
